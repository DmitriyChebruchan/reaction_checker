#!/usr/bin/env python3
from reaction_checker.reaction_checker.reaction_checker \
    import reaction_checker


def main():
    reaction_checker()


if __name__ == '__main__':
    main()