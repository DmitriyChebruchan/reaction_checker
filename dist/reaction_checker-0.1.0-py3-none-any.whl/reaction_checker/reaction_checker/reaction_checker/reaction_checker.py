# function checks reaction time of user
import time


def reaction_checker():
    print('Press Enter to start')
    input()
    start = time.time()
    print('Press Enter to stop')
    input()
    stop = time.time()
    reaction_time = stop - start
    print('Your reaction time is: ' + str(reaction_time) + ' seconds')
    return reaction_time