#!/usr/bin/env python3
from reaction_checker.cli.cli import parcer
from reaction_checker.reaction_checker.reaction_checker import reaction_checker


def main():
    parced_result = parcer()
    reaction_checker(parced_result)


if __name__ == '__main__':
    main()