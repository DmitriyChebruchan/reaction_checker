# function checks reaction time of user
import time
import math
from playsound import playsound


# function returns updated list of elements in random order from input list
def randomize_list(input_list):
    import random
    output_list = []
    while len(input_list) > 0:
        element = random.choice(input_list)
        output_list.append(element)
        input_list.remove(element)
    return output_list



def reaction_checker():
    instructions()

    test_run()
    list_of_numbers = randomize_list([2, 3, 4, 5] * 4) 

    result = {}

    collected_results = {2: [], 3: [], 4: [], 5: []}
    for n in range(len(list_of_numbers)):
        collected_results[list_of_numbers[n]].append(checker(list_of_numbers[n], n+1))
  
    tau = calculate_tau(result)
    sigma = sigma_calculator(result, tau)

    options = {'Холерик': [0.7, 0.8],
               'Сангвиник': [0.8, 0.9],
               'Флегматик': [0.9, 1],
               'Меланхолик': [1, 1.1]}

    for key, value in options.items():
        if value[0] <= tau <= value[1]:
            print('Ваш тип темперамента - {}'.format(key))
            break
    print('_________________________________________________________\n')


# function that prints instuctions
def instructions():
    print('''
    Привет! Это программа для тестирования реакции.
    Сейчас будет запущен тест 5 раз по каждому из 4 временных отрезков.
    Временные отрезки: 2, 3, 4, 5 секунд.
    Чтобы запустить таймер или остановить таймер нажмите Enter на клавиатуре.
    ''')


# function that runs the test run
def test_run():
    input('\nОтрепетируем. \nНажмите Enter один раз, чтобы начать.\n')
    playsound('/Users/dmitriychebruchan/reaction_checker/sound/start.wav')
    print('\nХорошо! Начнем тест.\n')
    print('Тест запущен.\n')
    print('Нажимайте Enter, чтобы остановить таймер.')
    input()
    playsound('/Users/dmitriychebruchan/reaction_checker/sound/start.wav')
    print('Таймер остановлен.\nТест завершен.\n')
    print('_________________________________________________________\n\n\n')


def sigma_calculator(result, tau):
    sigma = {}
    for key, value in result.items():
        element = value/int(key) - tau
        sigma[key] = element
    print('Сигма: {}'.format(sigma))
    return sigma


def calculate_tau(result):
    tau = sum([x/2 for x in result.values()])/4
    print('тау: {}'.format(tau))
    return tau


def checker(time_period, try_number):
    print('Номер текущей поптыки - {} из 20\n'.format(try_number))
    print('Нажмите Enter на клавиатуре, чтобы запустить таймер.')
    print('Нажмите ее снова, чтобы остановить таймер через {} секунд.'.format(time_period))
    input()
    start = time.time()
    playsound('/Users/dmitriychebruchan/reaction_checker/sound/start.wav')
    print('Таймер запущен.')
    
    input()
    stop = time.time()
    playsound('/Users/dmitriychebruchan/reaction_checker/sound/finish.wav')
    print('Таймер остановлен.')
    reaction_time = round(stop - start, 6)
    print('Ваше время реакции записано. Переходим к следующей попытке.')
    print('_________________________________________________________\n\n\n')
    return reaction_time
