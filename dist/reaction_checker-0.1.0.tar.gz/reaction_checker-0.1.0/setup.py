# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['reaction_checker',
 'reaction_checker.cli',
 'reaction_checker.reaction_checker',
 'reaction_checker.scripts']

package_data = \
{'': ['*']}

install_requires = \
['autopep8>=1.7.0,<2.0.0',
 'flake8>=5.0.4,<6.0.0',
 'playsound>=1.3.0,<2.0.0',
 'pytest>=7.1.3,<8.0.0']

entry_points = \
{'console_scripts': ['reaction_checker = '
                     'reaction_checker.scripts.reaction_checker:main']}

setup_kwargs = {
    'name': 'reaction-checker',
    'version': '0.1.0',
    'description': 'Program checks reaction and tells your type of character',
    'long_description': 'None',
    'author': 'Dmitriy Chebruchan',
    'author_email': 'chebruchan2707@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
